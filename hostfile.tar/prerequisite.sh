#!/bin/bash

# timezone
sudo timedatectl set-timezone Asia/Seoul

# Yum package install
sudo yum install -y iproute
sudo yum install -y ipvsadm

# overlay network module 
sudo cat <<EOF | sudo tee /etc/modules-load.d/containerd.conf
overlay
br_netfilter
EOF
sudo modprobe overlay
sudo modprobe br_netfilter

# OS kernel parameter
sudo cat <<EOF | sudo tee /etc/sysctl.d/99-kubernetes-cri.conf
net.bridge.bridge-nf-call-iptables  = 1
net.ipv4.ip_forward                 = 1
net.bridge.bridge-nf-call-ip6tables = 1
EOF
sudo sysctl --system

# swapoff
sudo swapoff -a
sudo echo "swapoff -a" | tee -a /etc/rc.local

